<div class="container">
                    <div class="row align-items-center">
                        <div class="col-xxl-8 col-lg-6">
                            <div class="header-top-left">
                                <ul>
                                 <a href="mailto:info@tripzi.ca">Email ID: info@tripzi.ca</a>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xxl-4 col-lg-6">
                            <div class="topheader-info">
                                <div class="top-button f-right ">
                                    <a href="https://www.webmehigh.com/Tripzi/contact.php">Inquire Now</a>
                                </div>
                                <div class="header-language f-right">                        
                                    <select>
                                        <option data-display="English">English</option>
                                        <option value="1">French</option>

                                    </select>
                                </div>
                                <div class="header-location f-right">
                                    <ul>
                                        <li><i class="flaticon-pin"></i><a href="https://www.google.com/maps/place/4818+Westwinds+Dr+NE,+Calgary,+AB+T3J+3Z5,+Canada/@51.1004076,-113.9678374,17z/data=!3m1!4b1!4m10!1m2!2m1!1s4818+Westwinds+Dr,Ne,Calgary,+AB+T3J3Z5+office+No+%23+231+Green+Plaza+Building-A,+Above+Lovely+Sweetsp!3m6!1s0x53716483165fb1fb:0xc6c023f343f9ee3e!8m2!3d51.1004043!4d-113.9652625!15sCmQ0ODE4IFdlc3R3aW5kcyBEcixOZSxDYWxnYXJ5LCBBQiBUM0ozWjUgb2ZmaWNlIE5vICMgMjMxIEdyZWVuIFBsYXphIEJ1aWxkaW5nLUEsIEFib3ZlIExvdmVseSBTd2VldHNwkgEQZ2VvY29kZWRfYWRkcmVzc-ABAA!16s%2Fg%2F11cs6q006c?entry=ttu" target="_blank">Our Location</a></li>
                                    </ul>
                                </div>
                            </div>                  
                        </div>
                    </div>
                </div>