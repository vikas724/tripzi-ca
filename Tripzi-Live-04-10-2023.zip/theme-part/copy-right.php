<div class="row">
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                        <div class="footer-copyright__wrapper footer-copyright-home dis-none d-flex align-items-center theme-bg">
                            <div class="footer-copyright__wrapper__icon mr-10">
                                <i class="fal fa-headset"></i>
                            </div>
                            <div class="footer-copyright__wrapper__call-number copy-right-cell">
                                <span>Call - Or - SMS</span>
                                <h5><a href="tel:+1 587 893 7199">+1 587 893 7199</a></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8">
                        <div class="row subscribe-top align-items-center">
                            <div class="col-xxl-6 col-xl-6 col-lg-6">
                                <h4 class="copyright-title">
                                    Get More Update Join Our Newsletters
                                </h4>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 ">
                                <div class="subscribe-footer">
                                    <form action="#">
                                        <input type="email" placeholder="Enter your email">
                                        <button type="submit"><i class="fal fa-long-arrow-right"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="row copyright-botom-padding align-items-center">
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                                <div class="copyright-botom">
                                    <p>Copyright ©2023  <a href="#"> <span>Tripzi</span></a>. All Rights Reserved</p>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                                <div class="copyright-botom-right ">
                                    <ul>
                                        <li><a href="#">Privacy Policy</a></li>
                                        <li><a href="#">Terms & Condition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>