 <div class="row">
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6">
                        <div class="footer-about-1">
                            <div class="footer-about-1-content">
                                <div class="footer-logo footer-logo-3 mb-30">
                                    <a href="#"><img src="assets/img/footer-logo/f-logo.png" alt=""></a>
                                </div>
                                <p class="mb-50">We, at ‘Tripzi, swear by this and put stock in satisfying travel dreams that make you perpetually rich constantly</p>
                                <h4 class="footer-about-1__title mb-30">
                                    Follow Us
                                </h4>
                                <ul class="social_links">
                                    <li>
                                        <a class="" href="#">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="" href="#">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="" href="#">
                                            <i class="fab fa-instagram"></i>

                                        </a>
                                    </li>
                                    <li>
                                        <a class="" href="#">
                                            <i class="fab fa-pinterest-p"></i>
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-6">
                        <div class="footer-widget footer-2 footer-btm-mobile ml-30">
                            <h3 class="footer-widget__title mb-25">
                                Quick Links
                            </h3>
                            <ul class="footer-widget_menu-link">
                                <li><a href="https://www.webmehigh.com/Tripzi/index.php">Home</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/about.php">About Us</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/our-team.php">Our Team</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6">
                        <div class="footer-widget footer-3 footer-btm-mobile ml-50">
                            <h3 class="footer-widget__title mb-25">
                                Our Services
                            </h3>
                            <ul class="footer-widget_menu-link">
                                <li><a href="https://www.webmehigh.com/Tripzi/contact.php">Air Tickets</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/contact.php">Hotel Booking</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/contact.php">Cruise Tours</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/contact.php">Family Tours</a></li>
                                <li><a href="https://www.webmehigh.com/Tripzi/contact.php">MICE</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6">
                        <div class="footer-widget footer-4 footer-btm-mobile ml-40">
                            <h3 class="footer-widget__title mb-25">
                                Get in Touch
                            </h3>
                            <ul class="footer-widget_menu-link-info">
                                <li><a href="tel:+1 587 893 7199"><i class="far fa-phone-alt"></i> <span> +1 403 801 6969 <br>+1 587 893 7199</span> </a></li>
                                <li><a href="info@tripzi.ca"><i class="fal fa-envelope"></i> <span>info@tripzi.ca</span></a></li>
                                <li><a href="https://www.google.com/maps/place/4818+Westwinds+Dr+NE,+Calgary,+AB+T3J+3Z5,+Canada/@51.1004076,-113.9701334,17z/data=!3m1!4b1!4m10!1m2!2m1!1s4818+Westwinds+Dr,Ne,Calgary,+AB+T3J3Z5+office+No+%23+231+Green+Plaza+Building-A,+Above+Lovely+Sweetsp!3m6!1s0x53716483165fb1fb:0xc6c023f343f9ee3e!8m2!3d51.1004043!4d-113.9652625!15sCmQ0ODE4IFdlc3R3aW5kcyBEcixOZSxDYWxnYXJ5LCBBQiBUM0ozWjUgb2ZmaWNlIE5vICMgMjMxIEdyZWVuIFBsYXphIEJ1aWxkaW5nLUEsIEFib3ZlIExvdmVseSBTd2VldHNwkgEQZ2VvY29kZWRfYWRkcmVzc-ABAA!16s%2Fg%2F11cs6q006c?entry=ttu "target="_blank"><i class="fal fa-map-marker-alt"></i> <span>4818 WESTWINDS DR, NE,CALGARY,AB T3J 3Z5
                                            OFFICE  NO # 231 GREEN PLAZA BUILDING-A, ABOVE LOVELY SWEETS,</span> </a></li>
                            </ul>
                        </div>
                    </div>
                </div>