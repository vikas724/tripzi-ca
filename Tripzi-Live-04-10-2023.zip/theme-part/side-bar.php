<div class="sidebar__widget mb-30">
    <div class="sidebar__widget-content">
        <div class="cat-link">
            <ul>
                <li><a href="exotic-east-cost.php">EXOTIC EAST COST 06/07 DAYS</a></li>
                <li><a href="wonderfull-west-coast.php">WONDERFULL WEST COAST 06/07 DAY</a></li>
                <li><a href="amazing-america.php">AMAZING AMERICA 12/13 DAYS</a></li>
                <li><a href="ultimate-america.php">ULTIMATE AMERICA 19/20 DAYS</a></li>
                <li><a href="magical-east-cost.php">MAGICAL EAST COST 05/06 DAYS</a></li>
                <li><a href="mystic-canada.php">MYSTIC CANADA 12/13 DAYS</a></li>
                <li><a href="canadian-rockies.php">CANADIAN ROCKIES</a></li>
                <li><a href="exotic-mexico.php">EXOTIC MEXICO 08/09 DAYS</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="sidebar__widget mb-30 theme-bg pd-30">
    <div class="sidebar__widget-title title-white mb-40">
        <h4>Download</h4>
    </div>
    <div class="sidebar__widget-content">
        <ul>
            <li class="d-flex align-items-center mb-20 pdf-btm-border">
                <div class="docu__thumb mr-15">
                    <a href="contact.php"><i class="fas fa-file-pdf"></i></a>
                </div>
                <div class="docu__text">
                    <h6><a href="contact.php">Service Broohoru</a></h6>
                    <p>PDF<span>12Mb</span></p>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="faqfrm__visa mb-30">
    <div class="sidebar-title mb-40">
        <h3>Ask Us Custom</h3>
    </div>
    <div class="faqfrm__visa-form">
        <form method="post">
            <input type="text" name="con_name" placeholder="Name*">
            <input type="email" name="con_email" placeholder="Email*">
            <input type="tel" name="con_phone" placeholder="Phone*">

            <button class="theme-btn" type="submit" name="con_submit">Submit Now</button>
        </form>
    </div>
</div>